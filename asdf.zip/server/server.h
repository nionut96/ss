#ifndef _SERVER_H_
#define _SERVER_H_

void
Log(
    const char *Format,
    ...
    );

#endif _SERVER_H_
